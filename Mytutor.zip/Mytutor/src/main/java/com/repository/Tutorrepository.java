package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.model.Tutor;

@Repository
public interface Tutorrepository extends JpaRepository<Tutor, String>{

	@Query("select t from Tutor t where userId=?1 and password=?2")
	Tutor validateTutor(String userId,String password);
}
