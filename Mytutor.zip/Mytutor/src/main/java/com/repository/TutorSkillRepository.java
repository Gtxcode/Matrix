package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.model.Tutor;
import com.model.TutorSkill;

public interface TutorSkillRepository extends JpaRepository<TutorSkill, String> {

	
}
