package com.repository;

public interface TutorTimeSlotRepository {

}
