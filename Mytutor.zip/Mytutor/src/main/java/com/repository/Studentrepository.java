package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.model.Student;

@Repository
public interface Studentrepository extends JpaRepository<Student, String> {

	@Query("select s from Student s where userId=?1 and password=?2")
	Student validateStudent(String userId,String password);
}
