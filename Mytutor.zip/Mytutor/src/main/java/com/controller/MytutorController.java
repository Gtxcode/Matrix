package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.Admin;
import com.model.Student;
import com.model.Tutor;
import com.repository.Adminrepository;
import com.repository.Studentrepository;
import com.repository.Tutorrepository;

@Controller
public class MytutorController {
	
	@Autowired
	Adminrepository adminRepository;
	
	@Autowired 
	Studentrepository studentRepository;
	
	@Autowired
	Tutorrepository tutorRepository;

	@RequestMapping(value="/Adminlogin", method = RequestMethod.GET)
		public String adminLoginPage(@ModelAttribute("admin") Admin admin){
		 	admin=new Admin();
			return "Adminlogin";
		}
	
	@RequestMapping(value="/validateadmin", method=RequestMethod.GET)
	public String validateAdmin(@ModelAttribute("admin") Admin admin, Model model){
		
		Admin admin1 = adminRepository.validateAdmin(admin.getUserId(),admin.getPassword());
		if(admin1!=null){
		model.addAttribute("userId",admin1.getUserId());
		return "Adminhome";
		}else{
			model.addAttribute("status","Invalid username/password");
			return "Adminlogin";
		}
		
	}
	
	@RequestMapping(value="/Studentlogin", method = RequestMethod.GET)
	public String studentLoginPage(@ModelAttribute("student") Student student){
	 	student=new Student();
		return "Studentlogin";
	}
	
	@RequestMapping(value="/validatestudent", method=RequestMethod.GET)
	public String validateStudent(@ModelAttribute("student") Student student, Model model){
		
		Student student1 = studentRepository.validateStudent(student.getUserId(),student.getPassword());
		if(student1!=null){
		model.addAttribute("userId",student1.getUserId());
		return "Studenthome";
		}else{
			model.addAttribute("status","Invalid username/password");
			return "Studentlogin";
		}
		
	}
	
	@RequestMapping(value="/registerStudent", method = RequestMethod.POST)
	public String registerStudent(@Valid @ModelAttribute("student") Student student,BindingResult bindingResult) {
		//System.out.println(bindingResult.hasErrors());
		if(bindingResult.hasErrors()) {
			System.out.println("ui details not correct");
			return "StudentRegistration";
		}
		studentRepository.save(student);
	return "Studentlogin";
	}
	@ModelAttribute("SecurityQuestionList")
    public List<String> populateExpense() {
           List<String>  SecurityQuestionList = new ArrayList<String>();
           SecurityQuestionList.add("who is your ideal?");
           SecurityQuestionList.add("What is your nickname?");
           SecurityQuestionList.add("what is your favourite colour?");
           return SecurityQuestionList;
	}
	
	@RequestMapping(value="/showStudRegPage", method = RequestMethod.GET)
	public String showStudRegPage(@ModelAttribute("student") Student student){
	 	student=new Student();
		return "StudentRegistration";
	}
	
	@RequestMapping(value="/Tutorlogin", method = RequestMethod.GET)
	public String tutorLoginPage(@ModelAttribute("tutor") Tutor tutor){
	 	tutor=new Tutor();
		return "Tutorlogin";
	}
	
	@RequestMapping(value="/validatetutor", method=RequestMethod.GET)
	public String validateTutor(@ModelAttribute("tutor") Tutor tutor, Model model){
		
		 Tutor tutor1 = tutorRepository.validateTutor(tutor.getUserId(),tutor.getPassword());
		if(tutor1!=null){
		model.addAttribute("userId",tutor1.getUserId());
		return "Tutorhome";
		}else{
			model.addAttribute("status","Invalid username/password");
			return "Tutorlogin";
		}
		
	}
	
	@RequestMapping(value="/registerTutor", method = RequestMethod.POST)
	public String registerTutor(@Valid @ModelAttribute("tutor")  Tutor tutor,BindingResult bindingResult) {
		//System.out.println(bindingResult.hasErrors());
		if(bindingResult.hasErrors()) {
			System.out.println("ui details not correct");
			return "TutorRegistration";
		}
		tutorRepository.save(tutor);
	return "Tutorlogin";
	}
	
	@ModelAttribute("SecurityQuestionList")
    public List<String> populateExpense1() {
           List<String>  SecurityQuestionList = new ArrayList<String>();
           SecurityQuestionList.add("who is your ideal?");
           SecurityQuestionList.add("What is your nickname?");
           SecurityQuestionList.add("what is your favourite colour?");
           return SecurityQuestionList;
	}
	
	@RequestMapping(value="/showTutRegPage", method = RequestMethod.GET)
	public String showTutRegPage(@ModelAttribute("tutor")  Tutor tutor){
		tutor=new Tutor();
		return "TutorRegistration";
	}
	
	
	
		
	
}
