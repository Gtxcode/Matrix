package com.model;

public class TutorTimeSlot {

}
