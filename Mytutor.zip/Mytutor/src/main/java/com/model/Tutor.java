package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Tutor{
               


                @NotEmpty(message="First Name can't be blank")
                private String firstName;
                @NotEmpty(message="Last Name can't be blank")
    private String lastName;
                @NotEmpty(message="Date of Birth can't be blank")
    private String DOB;
                @NotEmpty(message="It is mendatory")
    private String gender;
                @NotEmpty(message="It can't be empty")
    private String contactNumber;
                
                @Id
                @Pattern(regexp="[A-Za-z]+[0-9]+",message="User Id should be alphanumeric")
    private String userId;
                
                @Pattern(regexp="[A-Za-z]+[0-9]+",message="Password should be alphanumeric")
                @Size(min=6,message="password should be >=6")
                  private String password;
                @NotEmpty(message="You must have to choose asecurity question")
    private String SecurityQuestion;
                @NotEmpty(message="Give a proper security answer")
    private String answer;
    public Tutor() {
		// TODO Auto-generated constructor stub
	}
    
    
    
                public Tutor( String firstName,
			String lastName,
			 String dOB,
			String gender,
			 String contactNumber,
			 String userId,
			 String password,
			String securityQuestion,
			 String answer) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		DOB = dOB;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.userId = userId;
		this.password = password;
		SecurityQuestion = securityQuestion;
		this.answer = answer;
	}



				public String getAnswer() {
                                return answer;
                }
                public void setAnswer(String answer) {
                                this.answer = answer;
                }
                public String getSecurityQuestion() {
                                return SecurityQuestion;
                }
                public void setSecurityQuestion(String securityQuestion) {
                                SecurityQuestion = securityQuestion;
                }
                public String getFirstName() {
                                return firstName;
                }
                public void setFirstName(String firstName) {
                                this.firstName = firstName;
                }
                public String getLastName() {
                                return lastName;
                }
                public void setLastName(String lastName) {
                                this.lastName = lastName;
                }
                public String getDOB() {
                                return DOB;
                }
                public void setDOB(String dOB) {
                                DOB=dOB;
                
                }
                public String getGender() {
                                return gender;
                }
                public void setGender(String gender) {
                                this.gender = gender;
                }
                public String getContactNumber() {
                                return contactNumber;
                }
                public void setContactNumber(String contactNumber) {
                                this.contactNumber = contactNumber;
                }
                public String getUserId() {
                                return userId;
                }
                public void setUserId(String userId) {
                                this.userId = userId;
                }
                public String getPassword() {
                                return password;
                }
                public void setPassword(String password) {
                                this.password = password;
                }
    
    
                
}
