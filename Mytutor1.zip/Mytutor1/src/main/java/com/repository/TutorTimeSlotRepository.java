package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.TutorSkill;
import com.model.TutorTimeSlot;

public interface TutorTimeSlotRepository extends JpaRepository<TutorTimeSlot, String>{

}
