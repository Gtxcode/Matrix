package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class TutorTimeSlot {
	@Id
	private String userId;
	private String startTim;
	private String endTim;
	private String dat;
	private String skill;
	private String skill1;
	private String skill2;
	
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getSkill1() {
		return skill1;
	}
	public void setSkill1(String skill1) {
		this.skill1 = skill1;
	}
	public String getSkill2() {
		return skill2;
	}
	public void setSkill2(String skill2) {
		this.skill2 = skill2;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStartTim() {
		return startTim;
	}
	public void setStartTim(String startTim) {
		this.startTim = startTim;
	}
	public String getEndTim() {
		return endTim;
	}
	public void setEndTim(String endTim) {
		this.endTim = endTim;
	}
	public String getDat() {
		return dat;
	}
	public void setDat(String dat) {
		this.dat = dat;
	}
	public TutorTimeSlot(String userId, String startTim, String endTim, String dat, String skill, String skill1,
			String skill2) {
		super();
		this.userId = userId;
		this.startTim = startTim;
		this.endTim = endTim;
		this.dat = dat;
		this.skill = skill;
		this.skill1 = skill1;
		this.skill2 = skill2;
	}
	public TutorTimeSlot() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
