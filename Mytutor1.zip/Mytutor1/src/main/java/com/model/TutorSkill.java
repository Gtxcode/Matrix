package com.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;

@Entity
public class TutorSkill {

	@Id
	 
private String tutorId;
public String getTutorId() {
	return tutorId;
}

public void setTutorId(String tutorId) {
	this.tutorId = tutorId;
}

private String skill;
private String skill1;
private String skill2;

private String startTim;
private String endTim;
private String dat;



public String getStartTim() {
	return startTim;
}

public void setStartTim(String startTim) {
	this.startTim = startTim;
}

public String getEndTim() {
	return endTim;
}

public void setEndTime(String endTim) {
	this.endTim= endTim;
}

public String getDat() {
	return dat;
}

public void setDate(String dat) {
	this.dat = dat;
}

public String getSkill1() {
	return skill1;
}

public void setSkill1(String skill1) {
	this.skill1 = skill1;
}

public String getSkill2() {
	return skill2;
}

public void setSkill2(String skill2) {
	this.skill2 = skill2;
}

public TutorSkill() {
	super();
	// TODO Auto-generated constructor stub
}

public TutorSkill(String skill) {
	super();
	this.skill = skill;
}

public String getSkill() {
	return skill;
}

public void setSkill(String skill) {
	this.skill = skill;
}
}
