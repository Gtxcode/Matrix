package com.controller;

import java.util.ArrayList;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.Admin;
import com.model.Student;
import com.model.Tutor;
import com.model.TutorSkill;
import com.model.TutorTimeSlot;
import com.repository.Adminrepository;
import com.repository.Studentrepository;
import com.repository.TutorSkillRepository;
import com.repository.TutorTimeSlotRepository;
import com.repository.Tutorrepository;

@Controller
public class MytutorController {
	
	@Autowired
	Adminrepository adminRepository;
	
	@Autowired 
	Studentrepository studentRepository;
	
	@Autowired
	Tutorrepository tutorRepository;
	
	@Autowired
	TutorSkillRepository tutorSkillRepository;
	@Autowired
	TutorTimeSlotRepository tutorTimeSlotRepository;
//Admin Part
	@RequestMapping(value="/showAdminlogin", method = RequestMethod.GET)
		public String adminLoginPage(@ModelAttribute("admin") Admin admin){
		 	admin=new Admin();
			return "Adminlogin";
		}
	
	@RequestMapping(value="/validateadmin", method=RequestMethod.GET)
	public String validateAdmin(@Valid @ModelAttribute("admin") Admin admin,BindingResult bindingResult, Model model) {
		//System.out.println(bindingResult.hasErrors());
		if(bindingResult.hasErrors()) {
			model.addAttribute("status","Invalid username/password");
			return "Adminlogin";
		}else{
	System.out.println(admin.getUserId()+" "+admin.getPassword());
		Admin admin1 = adminRepository.validateAdmin(admin.getUserId(),admin.getPassword());
		System.out.println(admin1);
		if(admin1!=null){
		model.addAttribute("userId",admin1.getUserId());
		return "Adminhome";
		}else{
			model.addAttribute("status","Invalid username/password");
			return "Adminlogin";
		}
		}
		
	}
	
	// Student Part
	
	@RequestMapping(value="/Studentlogin", method = RequestMethod.GET)
	public String studentLoginPage(@ModelAttribute("student") Student student){
	 	student=new Student();
		return "Studentlogin";
	}
	
	@RequestMapping(value="/validatestudent", method=RequestMethod.GET)
	public String validateStudent(@ModelAttribute("student") Student student, Model model){
		
		Student student1 = studentRepository.validateStudent(student.getUserId(),student.getPassword());
		if(student1!=null){
		model.addAttribute("userId",student1.getUserId());
		return "Studenthome";
		}else{
			model.addAttribute("status","Invalid username/password");
			return "Studentlogin";
		}
		
	}
	
	@RequestMapping(value="/registerStudent", method = RequestMethod.GET)
	public String registerStudent(@Valid @ModelAttribute("student") Student student,BindingResult bindingResult) {
		//System.out.println(bindingResult.hasErrors());
		if(bindingResult.hasErrors()) {
			System.out.println("ui details not correct");
			return "StudentRegistration";
		}
		studentRepository.save(student);
	return "Studentlogin";
	}
	
	@ModelAttribute("SecurityQuestionList")
    public List<String> populateSecurity() {
           List<String>  SecurityQuestionList = new ArrayList<String>();
           SecurityQuestionList.add("who is your ideal?");
           SecurityQuestionList.add("What is your nickname?");
           SecurityQuestionList.add("what is your favourite colour?");
           return SecurityQuestionList;
	}
	
	@RequestMapping(value="/showStudloginPage", method = RequestMethod.GET)
	public String showStudloginPage(@ModelAttribute("student") Student student){
	 	student=new Student();
		return "Studhome";
	}
	
	@RequestMapping(value="/showStudRegPage", method = RequestMethod.GET)
	public String showStudRegPage(@ModelAttribute("student") Student student){
	 	student=new Student();
		return "StudentRegistration";
	}
	
	
	// Tutor Part
	
	
	@RequestMapping(value="/Tutorlogin", method = RequestMethod.GET)
	public String tutorLoginPage(@ModelAttribute("tutor") Tutor tutor){
	 	tutor=new Tutor();
		return "Tutorlogin";
	}
	
	@RequestMapping(value="/validatetutor", method=RequestMethod.GET)
	public String validateTutor(@ModelAttribute("tutor") Tutor tutor, Model model){
		
		 Tutor tutor1 = tutorRepository.validateTutor(tutor.getUserId(),tutor.getPassword());
		if(tutor1!=null){
		model.addAttribute("userId",tutor1.getUserId());
		return "Tutorhome";
		}else{
			model.addAttribute("status","Invalid username/password");
			return "Tutorlogin";
		}
		
	}
	
	@RequestMapping(value="/registerTutor", method = RequestMethod.GET)
	public String registerTutor(@Valid @ModelAttribute("tutor")  Tutor tutor,BindingResult bindingResult,Model m) {
		//System.out.println(bindingResult.hasErrors());
		if(bindingResult.hasErrors()) {
			
			return "TutorRegistration";
		}
		tutorRepository.save(tutor);
		
	return "Tutorlogin";
	}
	
	@RequestMapping(value="/showTutRegPage", method = RequestMethod.GET)
	public String showTutRegPage(@ModelAttribute("tutor")  Tutor tutor){
		tutor=new Tutor();
		return "TutorRegistration";
	}
	
	@RequestMapping(value="/showTutloginPage", method = RequestMethod.GET)
	public String showTutloginPage(@ModelAttribute("tutor")  Tutor tutor){
		tutor=new Tutor();
		return "Tutorhome";
	}
	
	@ModelAttribute("skillList")
    public List<String> populateSkill() {
           List<String>  skillList = new ArrayList<String>();
           skillList.add("C/C++");
           skillList.add("Java");
           skillList.add("Python");
           skillList.add("None");
           return skillList;
	}
	@ModelAttribute("skillList1")
    public List<String> populateSkill1() {
           List<String>  skillList1 = new ArrayList<String>();
           skillList1.add("Mysql");
           skillList1.add("MongoDB");
           skillList1.add("Oracle");
           skillList1.add("None");
           return skillList1;
	}
	@ModelAttribute("skillList2")
    public List<String> populateSkill2() {
           List<String>  skillList2= new ArrayList<String>();
           skillList2.add("Data Analytics");
           skillList2.add("Apache Spark");
           skillList2.add("Pig");
           skillList2.add("Hadoop");
           skillList2.add("None");
           return skillList2;
	}
	
	@RequestMapping(value="/showAddSkill", method = RequestMethod.GET)
	public String showaddskillPage(@ModelAttribute("tutorSkill") TutorSkill tutorSkill, Model m){
	
	 	tutorSkill=new TutorSkill();
		return "AddSkill";
	}
	@RequestMapping(value="/AddSkill", method = RequestMethod.GET)
	public String addskillPage(@ModelAttribute("tutorSkill") TutorSkill tutorSkill,BindingResult bindingResult, Model m){
		
if(bindingResult.hasErrors()) {
	m.addAttribute("status","Invalid Details");
		return "AddSkill";
			
		}
		m.addAttribute("status","Skills Added Successfully");
		tutorSkillRepository.save(tutorSkill);
		
		return "AddSkill";
	}
	@RequestMapping(value="/showEditSkill", method = RequestMethod.GET)
	public String showeditskillPage(@ModelAttribute("tutorSkill") TutorSkill tutorSkill, Model m){
	
	 	tutorSkill=new TutorSkill();
		return "EditSkill";
	}
	@RequestMapping(value="/EditSkill", method = RequestMethod.GET)
	public String editSkillPage(@ModelAttribute("tutorSkill") TutorSkill tutorSkill, BindingResult bindingResult,Model m){
		if(bindingResult.hasErrors()) {
			m.addAttribute("status","Invalid Details");
			return "EditSkill";
				
			}
			m.addAttribute("status","Skills Updated Successfully!!");
			tutorSkillRepository.save(tutorSkill);
			
		
		return "EditSkill";
	}
	//TimeSlot
	
	@RequestMapping(value="/showAddSlot", method = RequestMethod.GET)
	public String showaddslotPage(@ModelAttribute("tutorSlot") TutorTimeSlot tutorSlot, Model m){
	
		tutorSlot=new TutorTimeSlot();
		return "TutorTimeSlot";
	}
	@RequestMapping(value="/TutorTimeSlot", method = RequestMethod.GET)
	public String addslotPage(@ModelAttribute("tutorSlot")  TutorTimeSlot tutorSlot,BindingResult bindingResult, Model m){
		
if(bindingResult.hasErrors()) {
	m.addAttribute("status","Invalid Details");
		return "TutorTimeSlot";
			
		}
		m.addAttribute("status","Skills Added Successfully");
		tutorTimeSlotRepository.save(tutorSlot);
		
		return "TutorTimeSlot";
	}
	
}
